
package cpf;
import javax.swing.JOptionPane;
public class CPF {
    
    
    public static void main(String[] args) {
       Model.Criador.criar1();
       Model.Criador.criar2();
       Model.Criador.resultado();
      
        
      
        
    }
    
}
